select * from aparelho;
select * from clientes;
select * from funcionarios;
select * from ordem;
select * from pecas;
select * from pecas_ordem;
select * from servicos;
select * from servicos_ordem;