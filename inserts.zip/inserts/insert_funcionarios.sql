select * from funcionarios;
insert into funcionarios(nome,cpf,endereco,telefone,salario)
values	('ze maria','55555555555','rua A, 23, s j ribamar-MA','9899999999','1200'),
		('brandao','66666666666','rua A, 40, s j ribamar-MA','9899999999','1200'),
		('malaquias','77777744444','rua A, 45, s j ribamar-MA','9899999999','1200'),
		('maria joao','77777777777','rua A, 45, s j ribamar-MA','9899999999','1200'),
		('maria maria','88888888888','rua A, 45, s j ribamar-MA','9899999999','1200');



#DELETE FROM `assistencia`.`funcionarios` WHERE (`id` = '2');


