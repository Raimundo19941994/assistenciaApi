select * from clientes;
insert into clientes(nome,cpf,endereco,telefone)
values
	('joao','11111111111','rua B 24 s j ribamar-MA','98888888888'),
	('jose','22222222222','rua A 25 s j ribamar-MA','98777777777'),
    ('maria','33333333333','rua C 26 s j ribamar-MA','986666666666'),
    ('wolvewrine','44444444444','rua D 27 s j ribamar-MA','98555555555'),
    ('magneto','30955512398','rua D 27 s j ribamar-MA','98555555555');

#DELETE FROM `assistencia`.`clientes` WHERE (`id` = '2');