select*from servicos;
insert into servicos(descricao, preco, horas)
values ('troca de placa', '300','2'),
		('troca de tela', '400','2'),
		('formatacao', '150','2'),
        ('troca de hd', '100','2'),
        ('troca de cooler', '100','2');