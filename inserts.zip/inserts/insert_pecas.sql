select *from pecas;
insert into pecas (descricao, quantidade_minima, quantidade_atual, pco_custo, pco_venda)
values	('hd','1','20','100','50'),
		('tela','1','25','400','200'),
		('placa','1','40','200','100'),
		('memoria ram','1','20','250','125'),
		('teclado','1','20','50','25');