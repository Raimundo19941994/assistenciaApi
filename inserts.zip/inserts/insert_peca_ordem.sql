select * from pecas_ordem;
insert into pecas_ordem(quantidade, preco, pecas_id, ordem_id)
values	('20','100','1','1'),
		('20','100','2','2'),
		('20','100','3','3'),
		('20','100','4','4'),
		('20','100','5','5');


#CALL atualiza_total_pecas(1);

