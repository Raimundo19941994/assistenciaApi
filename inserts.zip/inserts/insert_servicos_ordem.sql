select * from servicos_ordem;
insert into servicos_ordem(quantidade, preco, servicos_id, ordem_id)
values  ('1','300','1','1'),
		('1','400','2','2'),
        ('1','150','3','3'),
        ('1','100','4','4'),
        ('1','100','5','5');