select * from aparelho;
insert into aparelho(ano, descricao, clientes_id, modelo, cor)
values	('2010','não liga','1','dell 1155','vermelho'),
		('2020','tela quebrada','2','acer 2200','azul'),
		('2011','sem o sistema','3','toshiba 1414','verde'),
		('2016','caiu e quebrou','4','positivo 1100','prateado'),
		('2024','desliga sozinho','5','generico 1154','preto');


#DELETE FROM `assistencia`.`aparelho` WHERE (`id` = '2');




